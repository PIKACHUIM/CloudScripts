#include "../ck_ticket_pb.h"
#include "validate.h"
